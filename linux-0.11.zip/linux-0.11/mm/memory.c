/*
 *  linux/mm/memory.c
 *
 *  (C) 1991  Linus Torvalds
 */

/*
 * demand-loading started 01.12.91 - seems it is high on the list of
 * things wanted, and it should be easy to implement. - Linus
 */

/*
 * Ok, demand-loading was easy, shared pages a little bit tricker. Shared
 * pages started 02.12.91, seems to work. - Linus.
 *
 * Tested sharing by executing about 30 /bin/sh: under the old kernel it
 * would have taken more than the 6M I have free, but it worked well as
 * far as I could see.
 *
 * Also corrected some "invalidate()"s - I wasn't doing enough of them.
 */

#include <signal.h>

#include <asm/system.h>

#include <linux/sched.h>
#include <linux/head.h>
#include <linux/kernel.h>

volatile void do_exit(long code);
//内存溢出 用户内存
static inline volatile void oom(void)
{
	printk("out of memory\n\r");
	do_exit(SIGSEGV);
}

//MMU 往cr3中重新载入页目录表
//TLB  
//刷新TLB invalidate
#define invalidate() \
__asm__("movl %%eax,%%cr3"::"a" (0))


//在不改变head.s 这些不能被改变
/* these are not to be changed without changing head.s etc */
#define LOW_MEM 0x100000
//物理内存总大小
#define PAGING_MEMORY (15*1024*1024)

//物理内存页一共的页数
#define PAGING_PAGES (PAGING_MEMORY>>12)
#define MAP_NR(addr) (((addr)-LOW_MEM)>>12) //addr物理内存地址  物理内存的页号
#define USED 100    //页面被占用的标准


//计算第几个页表项 一个页表项4K 
//给定的线性地址是否在当前代码中
#define CODE_SPACE(addr) ((((addr)+4095)&~4095) < \
current->start_code + current->end_code)

static long HIGH_MEMORY = 0;


//拷贝一页内存 内嵌汇编
#define copy_page(from,to) \
__asm__("cld ; rep ; movsl"::"S" (from),"D" (to),"c" (1024):"cx","di","si")

//定义数组，描述物理内存的使用情况
static unsigned char mem_map [ PAGING_PAGES ] = {0,};

/*
 * Get physical address of first (actually last :-) free page, and mark it
 * used. If no free pages left, return 0.
 */
 //获取一个物理空闲内存页，返回物理空闲内存页的基地址
unsigned long get_free_page(void)
{
register unsigned long __res asm("ax");

__asm__("std ; repne ; scasb\n\t"
	"jne 1f\n\t"
	"movb $1,1(%%edi)\n\t"
	"sall $12,%%ecx\n\t"
	"addl %2,%%ecx\n\t"
	"movl %%ecx,%%edx\n\t"
	"movl $1024,%%ecx\n\t"
	"leal 4092(%%edx),%%edi\n\t"
	"rep ; stosl\n\t"
	"movl %%edx,%%eax\n"
	"1:"
	:"=a" (__res)
	:"0" (0),"i" (LOW_MEM),"c" (PAGING_PAGES),
	"D" (mem_map+PAGING_PAGES-1)
	:"di","cx","dx");
return __res;
}

/*
 * Free a page of memory at physical address 'addr'. Used by
 * 'free_page_tables()'
 */
 //释放物理内存页
void free_page(unsigned long addr)
{
	if (addr < LOW_MEM) return;
	if (addr >= HIGH_MEMORY)
		panic("trying to free nonexistent page");
	addr -= LOW_MEM;
	addr >>= 12;
	if (mem_map[addr]--) return;
	mem_map[addr]=0;
	panic("trying to free free page");
}

/*
 * This function frees a continuos block of page tables, as needed
 * by 'exit()'. As does copy_page_tables(), this handles only 4Mb blocks.
 */
 //连续的线性空间物理内存的释放  from ： 线性地址
int free_page_tables(unsigned long from,unsigned long size)
{
	unsigned long *pg_table;
	unsigned long * dir, nr;
	//4M 取整
	if (from & 0x3fffff)
		panic("free_page_tables called with wrong alignment");
	if (!from)
		panic("Trying to free up swapper memory space");
	
	//size 要释放目录项的个数
	size = (size + 0x3fffff) >> 22;
	//from>>22 计算对应页目录项的地址
	dir = (unsigned long *) ((from>>20) & 0xffc); /* _pg_dir = 0 */
	for ( ; size-->0 ; dir++) {
		//如果页目录项最低为为1，说明该项不对应任何页表项
		if (!(1 & *dir))
			continue;
		//pg_table 页表项的基地址
		pg_table = (unsigned long *) (0xfffff000 & *dir);
		for (nr=0 ; nr<1024 ; nr++) {
			if (1 & *pg_table)//如果页表项最后一位不为0，说明对应相应的物理内存，就将对应的物理内存释放
				free_page(0xfffff000 & *pg_table);
			*pg_table = 0; //清空
			pg_table++;
		}
		free_page(0xfffff000 & *dir); //释放该页表所占用的内存
		*dir = 0; //页目录项置为0，注意 ，页表可以被释放，但页目录不能被释，只能将页目录项置为0
	}
	//更新TLB中的页表映射缓冲
	invalidate();
	return 0;
}

/*
 *  Well, here is one of the most complicated functions in mm. It
 * copies a range of linerar addresses by copying only the pages.
 * Let's hope this is bug-free, 'cause this one I don't want to debug :-)
 *
 * Note! We don't copy just any chunks of memory - addresses have to
 * be divisible by 4Mb (one page-directory entry), as this makes the
 * function easier. It's used only by fork anyway.
 *
 * NOTE 2!! When from==0 we are copying kernel space for the first
 * fork(). Then we DONT want to copy a full page-directory entry, as
 * that would lead to some serious memory waste - we just copy the
 * first 160 pages - 640kB. Even that is more than we need, but it
 * doesn't take any more memory - we don't copy-on-write in the low
 * 1 Mb-range, so the pages can be shared with the kernel. Thus the
 * special case for nr=xxxx.
 */
 //拷贝线性地址，在fork中调用
int copy_page_tables(unsigned long from,unsigned long to,long size)
{
	unsigned long * from_page_table;
	unsigned long * to_page_table;
	unsigned long this_page;
	unsigned long * from_dir, * to_dir;
	unsigned long nr;

	if ((from&0x3fffff) || (to&0x3fffff))
		panic("copy_page_tables called with wrong alignment");
	//把线性地址转换为目录项地址
	from_dir = (unsigned long *) ((from>>20) & 0xffc); /* _pg_dir = 0 */
	to_dir = (unsigned long *) ((to>>20) & 0xffc);
	//目录项的个数
	size = ((unsigned) (size+0x3fffff)) >> 22;
	for( ; size-->0 ; from_dir++,to_dir++) {
		//如果要拷贝的目的页目录地址已有数据，就报错
		if (1 & *to_dir)
			panic("copy_page_tables: already exist");
		//如果源目录项没有对应页表，就continue;
		if (!(1 & *from_dir))
			continue;
		//取页表地址
		from_page_table = (unsigned long *) (0xfffff000 & *from_dir);
		//给 to 的页表申请了一块物理内存
		if (!(to_page_table = (unsigned long *) get_free_page()))
			return -1;	/* Out of memory, see freeing */
		//将to对应的页表指向这块刚申请的内存，并设置最后三位为111（权限位）
		*to_dir = ((unsigned long) to_page_table) | 7;
		nr = (from==0)?0xA0:1024; //如果是内核进程，页表项只需要160项，如果是用户，则需要1024项
		//设置（copy）对应的页表项
		for ( ; nr-- > 0 ; from_page_table++,to_page_table++) {
			this_page = *from_page_table;
			if (!(1 & this_page))
				continue;
			//设置为只读权限
			this_page &= ~2;
			//赋值给新的页表项
			*to_page_table = this_page;
			if (this_page > LOW_MEM) {
				//赋值给旧的页表项
				*from_page_table = this_page;
				this_page -= LOW_MEM;
				//计算当前物理内存地址对应的为第几个内存页
				this_page >>= 12;
				//因为对这页物理内存设置了共享内存，所以设置其对应的项引用计数加一
				mem_map[this_page]++;
			}
		}
	}
	//更新TLB中的页表映射缓冲
	invalidate();
	return 0;
}

/*
 * This function puts a page in memory at the wanted address.
 * It returns the physical address of the page gotten, 0 if
 * out of memory (either when trying to access page-table or
 * page.)
 */
 //线性地址分配物理内存
unsigned long put_page(unsigned long page,unsigned long address)
{
	unsigned long tmp, *page_table;

/* NOTE !!! This uses the fact that _pg_dir=0 */

	if (page < LOW_MEM || page >= HIGH_MEMORY)
		printk("Trying to put page %p at %p\n",page,address);
	if (mem_map[(page-LOW_MEM)>>12] != 1)
		printk("mem_map disagrees with %p at %p\n",page,address);
	page_table = (unsigned long *) ((address>>20) & 0xffc);
	if ((*page_table)&1)
		page_table = (unsigned long *) (0xfffff000 & *page_table);
	else {
		if (!(tmp=get_free_page()))
			return 0;
		*page_table = tmp|7;
		page_table = (unsigned long *) tmp;
	}
	page_table[(address>>12) & 0x3ff] = page | 7;
/* no need for invalidate */
	return page;
}

//解除写保护函数  （table_entry ：页表项指针）
void un_wp_page(unsigned long * table_entry)
{
	unsigned long old_page,new_page;
	
	//4K取整 取物理内存的页基地址
	old_page = 0xfffff000 & *table_entry;
	
	//如果只有一个页表项指向这页内存
	if (old_page >= LOW_MEM && mem_map[MAP_NR(old_page)]==1) {
		*table_entry |= 2;
		invalidate();
		return;
	}
	//如果有多个页表项指向这页内存，就要重新获取一页空闲的物理内存页
	if (!(new_page=get_free_page()))
		oom();
	//老的内存页减一
	if (old_page >= LOW_MEM)
		mem_map[MAP_NR(old_page)]--;
	//更改内存页的权限
	*table_entry = new_page | 7;
	//刷新TLB
	invalidate();
	//拷贝老的内存页到新的内存页
	copy_page(old_page,new_page);
}	

/*
 * This routine handles present pages, when users try to write
 * to a shared page. It is done by copying the page to a new address
 * and decrementing the shared-page counter for the old page.
 *
 * If it's in code space we exit with a segment error.
 */
 
 //error_code 错误码   address 线性地址
 //异常中断调用，写保护异常调用
void do_wp_page(unsigned long error_code,unsigned long address)
{
#if 0
/* we cannot do this yet: the estdio library writes to code space */
/* stupid, stupid. I really want the libc.a from GNU */
	if (CODE_SPACE(address))
		do_exit(SIGSEGV);
#endif
	un_wp_page((unsigned long *)
		(((address>>10) & 0xffc) + (0xfffff000 &
		*((unsigned long *) ((address>>20) &0xffc)))));

}

//内存写验证
// address 线性地址
void write_verify(unsigned long address)
{
	unsigned long page;

	if (!( (page = *((unsigned long *) ((address>>20) & 0xffc)) )&1))
		return;
	page &= 0xfffff000;
	page += ((address>>10) & 0xffc);
	if ((3 & *(unsigned long *) page) == 1)  /* non-writeable, present */
		un_wp_page((unsigned long *) page);
	return;
}


//获得一个空的内存页
void get_empty_page(unsigned long address)
{
	unsigned long tmp;
//get_free_page（）申请物理内存页
//
	if (!(tmp=get_free_page()) || !put_page(tmp,address)) {
		free_page(tmp);		/* 0 is ok - ignored */
		oom();
	}
}

/*
 * try_to_share() checks the page at address "address" in the task "p",
 * to see if it exists, and if it is clean. If so, share it with the current
 * task.
 *
 * NOTE! This assumes we have checked that p != current, and that they
 * share the same executable.
 */
 //尝试去分享共享逻辑地址
 //address 逻辑地址
static int try_to_share(unsigned long address, struct task_struct * p)
{
	unsigned long from;
	unsigned long to;
	unsigned long from_page;
	unsigned long to_page;
	unsigned long phys_addr;
//页目录项
	from_page = to_page = ((address>>20) & 0xffc);
	//计算当前进程代码段所代表的页目录项开始地址
	from_page += ((p->start_code>>20) & 0xffc);
	to_page += ((current->start_code>>20) & 0xffc);
/* is there a page-directory at from? */
//from 页表基地址
	from = *(unsigned long *) from_page;
	//如果页表基地址不对应物理内存，直接返回
	if (!(from & 1))
		return 0;
	from &= 0xfffff000;//4K取整
	//from_page对应页表项地址
	from_page = from + ((address>>10) & 0xffc);
	//物理页地址
	phys_addr = *(unsigned long *) from_page;
/* is the page clean and present? */
	if ((phys_addr & 0x41) != 0x01)
		return 0;
	phys_addr &= 0xfffff000;
	if (phys_addr >= HIGH_MEMORY || phys_addr < LOW_MEM)
		return 0;
	//to 当前进程的页表地址
	to = *(unsigned long *) to_page;
	if (!(to & 1))
		if (to = get_free_page())
			*(unsigned long *) to_page = to | 7;
		else
			oom();
	to &= 0xfffff000;
	to_page = to + ((address>>10) & 0xffc);
	if (1 & *(unsigned long *) to_page)
		panic("try_to_share: to_page already exists");
/* share them: write-protect */
	*(unsigned long *) from_page &= ~2;
	*(unsigned long *) to_page = *(unsigned long *) from_page;
	invalidate();
	phys_addr -= LOW_MEM;
	phys_addr >>= 12;
	mem_map[phys_addr]++;
	return 1;
}

/*
 * share_page() tries to find a process that could share a page with
 * the current one. Address is the address of the wanted page relative
 * to the current data space.
 *
 * We first check if it is at all feasible by checking executable->i_count.
 * It should be >1 if there are other tasks sharing this inode.
 */
 //
static int share_page(unsigned long address)
{
	struct task_struct ** p;

	if (!current->executable)
		return 0;
	if (current->executable->i_count < 2)
		return 0;
	for (p = &LAST_TASK ; p > &FIRST_TASK ; --p) {
		if (!*p)
			continue;
		if (current == *p)
			continue;
		if ((*p)->executable != current->executable)
			continue;
		if (try_to_share(address,*p))
			return 1;
	}
	return 0;
}

//缺页中断
//发现页目录项或者页表项P位为0，触发缺页中断
//首先判断进程是只想要一个物理内存页呢，还是即想要一个物理内存页又想要从磁盘读数据
//如果仅想要一个物理内存页（需要一个栈堆空间），那么就给他，然后返回
//如果即想要一个物理内存页又想要从磁盘读数据，就先判断当前进程能不能和已经存在的进程共享一块内存，如果能映射，那么直接映射，如果实在没有，只能继续读
//从磁盘读出块号，设备号，映射到物理内存页上
//然后返回
void do_no_page(unsigned long error_code,unsigned long address)
{
	int nr[4];
	unsigned long tmp;
	unsigned long page;
	int block,i;

	address &= 0xfffff000;
	tmp = address - current->start_code;
	//如果程序才刚开始执行，或者进程需要一个栈堆空间
	if (!current->executable || tmp >= current->end_data) {
		get_empty_page(address);
		return;
	}
	//尝试当前逻辑地址是否能和其他进程进行共享内存
	if (share_page(tmp))
		return;
	//分配一页物理内存
	if (!(page = get_free_page()))
		oom();
/* remember that 1 block is used for header */
//所有的程序都有一块头部
	block = 1 + tmp/BLOCK_SIZE;
	for (i=0 ; i<4 ; block++,i++)
		nr[i] = bmap(current->executable,block);
	bread_page(page,current->executable->i_dev,nr);
	i = tmp + 4096 - current->end_data;
	tmp = page + 4096;
	while (i-- > 0) {
		tmp--;
		*(char *)tmp = 0;
	}
	//把从磁盘块读出的物理内存地址映射到线性地址上
	if (put_page(page,address))
		return;
	free_page(page);
	oom();
}

void mem_init(long start_mem, long end_mem)
{
	int i;

	HIGH_MEMORY = end_mem;
	for (i=0 ; i<PAGING_PAGES ; i++)
		mem_map[i] = USED;
	//用户主内存的开始页号
	i = MAP_NR(start_mem);
	//可以使用的用户内存大小
	end_mem -= start_mem;
	//可以使用的用户内存页的个数
	end_mem >>= 12;
	while (end_mem-->0)
		//将所有页号标志置为0
		mem_map[i++]=0;
}

//计算内存
void calc_mem(void)
{
	int i,j,k,free=0;
	long * pg_tbl;

//计算空间内存的页数
	for(i=0 ; i<PAGING_PAGES ; i++)
		if (!mem_map[i]) free++;
	printk("%d pages free (of %d)\n\r",free,PAGING_PAGES);
//每个目录项使用物理内存的页数
	for(i=2 ; i<1024 ; i++) {
		if (1&pg_dir[i]) {
			pg_tbl=(long *) (0xfffff000 & pg_dir[i]);
			for(j=k=0 ; j<1024 ; j++)
				if (pg_tbl[j]&1)
					k++;
			printk("Pg-dir[%d] uses %d pages\n",i,k);
		}
	}
}
